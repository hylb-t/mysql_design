create
    definer = root@localhost procedure pro_emp1(IN en varchar(4))
BEGIN
  SELECT ename 姓名,job 工作 FROM emp      -- 得到一个查询结果集
  WHERE empno LIKE en;
END;

