create
    definer = root@localhost procedure p_search(IN dn varchar(14))
BEGIN
SELECT empno,ename,job
FROM dept,emp
WHERE dept.deptno = emp.deptno AND dname LIKE CONCAT('%',dn,'%');
END;

