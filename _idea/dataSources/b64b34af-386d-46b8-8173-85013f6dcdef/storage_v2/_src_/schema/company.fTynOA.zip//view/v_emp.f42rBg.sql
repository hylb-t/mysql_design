create definer = root@localhost view v_emp as
select `company`.`v_dept_chk`.`empno` AS `empno`, `company`.`v_dept_chk`.`ename` AS `ename`
from `company`.`v_dept_chk`;

