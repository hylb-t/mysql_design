create definer = root@localhost view temp as
select `company`.`emp`.`empno`  AS `empno`,
       `company`.`emp`.`ename`  AS `ename`,
       `company`.`emp`.`job`    AS `job`,
       `company`.`dept`.`dname` AS `dname`
from (`company`.`emp` join `company`.`dept` on ((`company`.`emp`.`deptno` = `company`.`dept`.`deptno`)));

-- comment on column temp.empno not supported: 员工编号

-- comment on column temp.ename not supported: 员工姓名

-- comment on column temp.job not supported: 职位

-- comment on column temp.dname not supported: 部门名称

