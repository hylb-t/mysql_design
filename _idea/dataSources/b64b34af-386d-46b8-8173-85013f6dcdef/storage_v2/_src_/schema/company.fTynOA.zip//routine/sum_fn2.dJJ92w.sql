create
    definer = root@localhost function sum_fn2(n int) returns int
BEGIN
 DECLARE s,i INT;
 SET s=0,i=1;
 WHILE i<=n DO
 SET s=s+i;
 SET i=i+1;
 END WHILE;
 RETURN s;
END;

