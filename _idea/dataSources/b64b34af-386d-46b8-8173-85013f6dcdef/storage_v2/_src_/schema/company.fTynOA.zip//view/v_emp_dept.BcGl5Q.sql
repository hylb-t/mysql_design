create definer = root@localhost view v_emp_dept as
select `company`.`dept`.`dname` AS `dname`, `company`.`emp`.`empno` AS `empno`, `company`.`emp`.`ename` AS `ename`
from `company`.`dept`
         join `company`.`emp`
where (`company`.`dept`.`deptno` = `company`.`emp`.`deptno`)
order by `company`.`dept`.`deptno`;

-- comment on column v_emp_dept.dname not supported: 部门名称

-- comment on column v_emp_dept.empno not supported: 员工编号

-- comment on column v_emp_dept.ename not supported: 员工姓名

