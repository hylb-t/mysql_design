create
    definer = root@localhost procedure pro_dept(IN p_deptno char(2), IN p_dname varchar(14), IN p_loc varchar(13))
BEGIN
 INSERT INTO dept
 VALUES(p_deptno,p_dname,p_loc);
 END;

