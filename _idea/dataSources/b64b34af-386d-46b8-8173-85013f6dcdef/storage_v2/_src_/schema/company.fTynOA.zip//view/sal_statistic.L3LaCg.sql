create definer = root@localhost view sal_statistic as
select `company`.`emp`.`deptno`   AS `deptno`,
       max(`company`.`emp`.`sal`) AS `MAX(sal)`,
       avg(`company`.`emp`.`sal`) AS `AVG(sal)`
from `company`.`emp`
group by `company`.`emp`.`deptno`;

-- comment on column sal_statistic.deptno not supported: 部门编号

-- comment on column sal_statistic.topSal not supported: 工资

