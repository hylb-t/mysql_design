create
    definer = root@localhost procedure inse_to_dept(IN i_dno varchar(2), IN i_dname varchar(10), OUT succ varchar(20))
BEGIN
 IF EXISTS(SELECT * FROM dept  WHERE deptno=i_dno OR dname=i_dname) THEN
    SET succ="can't insert";     -- 注意双引号的使用
 ELSE 
    SET succ="success";
    INSERT INTO dept(deptno,dname) VALUES(i_dno,i_dname);
END IF;
END;

