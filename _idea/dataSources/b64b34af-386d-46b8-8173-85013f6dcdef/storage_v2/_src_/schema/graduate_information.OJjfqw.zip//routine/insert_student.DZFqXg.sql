create
    definer = root@localhost procedure insert_student(IN i_sno char(9), IN i_sname varchar(10), IN i_pro varchar(10),
                                                      IN i_state varchar(5), IN i_pno char(9), OUT succ varchar(20))
BEGIN
	IF EXISTS(SELECT * FROM student WHERE sno = i_sno) THEN
		SET succ = "can't insert!";
	ELSE 
		SET succ = "insert success!";
		INSERT INTO student VALUES(i_sno,i_sname,i_pro,i_cname,i_state,i_pno);
END IF;
END;

