create
    definer = root@localhost procedure delete_student(IN s_sno char(9), OUT succ varchar(20))
BEGIN
	IF NOT EXISTS(SELECT sno FROM student WHERE sno = s_sno) THEN
		SET succ = "no exisis!";
	ELSE 
		SET succ = "delete success!";
		DELETE FROM student WHERE sno=s_sno;
END IF;
END;

