create
    definer = root@localhost procedure insert_post(IN i_pno varchar(9), IN i_pname varchar(10), IN i_wages varchar(10),
                                                   IN i_comno char(9), OUT succ varchar(20))
BEGIN
	IF EXISTS(SELECT * FROM post WHERE pno = i_pno) THEN
		SET succ = "can't insert!";
	ELSE 
		SET succ = "insert success!";
		INSERT INTO post VALUES(i_pno,i_pname,i_wages,i_comno);
END IF;
END;

