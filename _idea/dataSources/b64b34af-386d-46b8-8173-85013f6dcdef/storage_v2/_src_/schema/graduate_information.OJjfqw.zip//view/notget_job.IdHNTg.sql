create definer = root@localhost view notget_job as
select `graduate_information`.`student`.`sno`   AS `sno`,
       `graduate_information`.`student`.`sname` AS `sname`,
       `graduate_information`.`student`.`pro`   AS `pro`,
       `graduate_information`.`student`.`state` AS `state`,
       `graduate_information`.`student`.`cno`   AS `cno`,
       `graduate_information`.`student`.`comno` AS `comno`,
       `graduate_information`.`student`.`pno`   AS `pno`
from `graduate_information`.`student`
where (`graduate_information`.`student`.`state` = '未就业');

