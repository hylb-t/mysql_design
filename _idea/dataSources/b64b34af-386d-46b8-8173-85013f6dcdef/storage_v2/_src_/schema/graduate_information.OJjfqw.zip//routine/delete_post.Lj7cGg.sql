create
    definer = root@localhost procedure delete_post(IN p_pno varchar(9), OUT succ varchar(20))
BEGIN 
	IF NOT EXISTS(SELECT pno FROM post  WHERE pno = p_pno ) THEN
		SET succ = "no extsis!";
	ELSE 
		SET succ = "delete success!";
		DELETE  FROM post WHERE pno=p_pno;
END IF; 
END;

